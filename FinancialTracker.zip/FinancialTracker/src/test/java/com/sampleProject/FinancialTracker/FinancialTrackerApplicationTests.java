package com.sampleProject.FinancialTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinancialTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
